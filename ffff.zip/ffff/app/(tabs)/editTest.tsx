import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, Pressable,
  Image, Alert, Platform, ActivityIndicator, ScrollView
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { db } from '../lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Picker } from '@react-native-picker/picker';
import * as ImagePicker from 'expo-image-picker';
import { testDictionary } from '../../testDictionary'; // ✅ تأكد من وجود الملف

export default function EditTest() {
  const { id } = useLocalSearchParams();
  const router = useRouter();

  const [testName, setTestName] = useState('');
  const [category, setCategory] = useState('');
  const [date, setDate] = useState(new Date());
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [extractedValues, setExtractedValues] = useState<Record<string, any>>({});
  const [suggestions, setSuggestions] = useState<string[]>([]); // ✅ جديد

  const categories = ['Blood', 'Urine', 'X-Ray', 'MRI', 'Other'];

  useEffect(() => {
    const fetchTest = async () => {
      try {
        const ref = doc(db, 'medicalTests', id as string);
        const snap = await getDoc(ref);
        if (snap.exists()) {
          const data = snap.data();
          setTestName(data.name || '');
          setCategory(data.category || '');
          setDate(new Date(data.date));
          setImageUri(data.imageUri || null);
          setExtractedValues(data.extractedValues || {});
          setSuggestions(data.suggestions || []); // ✅ جديد
        } else {
          Alert.alert('Error', 'Test not found.');
          router.back();
        }
      } catch (error) {
        console.error('Error loading test:', error);
      } finally {
        setLoading(false);
      }
    };

    if (id) fetchTest();
  }, [id]);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission required', 'Please allow access to media.');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });

    if (!result.canceled && result.assets.length > 0) {
      setImageUri(result.assets[0].uri);
    }
  };

  const handleUpdate = async () => {
    if (!testName || !category || !date) {
      Alert.alert('Missing info', 'Please complete all required fields.');
      return;
    }

    try {
    await updateDoc(doc(db, 'medicalTests', id as string), {
  name: testName,
  category,
  date: date.toISOString().split('T')[0],
  imageUri: imageUri || null,
  extractedValues,
  suggestions, // ✅ أضف هذا السطر لحفظها
});



      router.replace('../(tabs)/history');
    } catch (error) {
      console.error('Error updating test:', error);
    }
  };

  if (loading) return <ActivityIndicator style={{ marginTop: 50 }} />;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Edit Medical Test</Text>

      <Text style={styles.label}>Test Name</Text>
      <TextInput
        style={styles.input}
        value={testName}
        onChangeText={setTestName}
        placeholder="Enter test name"
      />

      <Text style={styles.label}>Category</Text>
      <View style={styles.pickerContainer}>
        <Picker
          selectedValue={category}
          onValueChange={(value) => setCategory(value)}
        >
          <Picker.Item label="-- Select a category --" value="" />
          {categories.map((cat) => (
            <Picker.Item key={cat} label={cat} value={cat} />
          ))}
        </Picker>
      </View>

      <Text style={styles.label}>Date</Text>
      <Pressable style={styles.dateButton} onPress={() => setShowDatePicker(true)}>
        <Text>{date.toISOString().split('T')[0]}</Text>
      </Pressable>

      {showDatePicker && (
        <DateTimePicker
          value={date}
          mode="date"
          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          onChange={(event, selectedDate) => {
            setShowDatePicker(false);
            if (selectedDate) setDate(selectedDate);
          }}
        />
      )}

      <Pressable style={styles.imageButton} onPress={pickImage}>
        <Text style={styles.imageButtonText}>
          {imageUri ? 'Change Image' : 'Select Image'}
        </Text>
      </Pressable>

      {imageUri && (
        <Image source={{ uri: imageUri }} style={styles.previewImage} />
      )}

      {extractedValues && Object.keys(extractedValues).length > 0 && (
  <View style={styles.extractedBox}>
    <Text style={styles.extractedTitle}>🧠 Test Results:</Text>
    {Object.entries(extractedValues).map(([key, value]) => (
      <View key={key} style={{ marginBottom: 12 }}>
        <Text style={styles.label}>{key} Result</Text>
        <TextInput
          style={styles.input}
          value={String(value)}
          onChangeText={(text) =>
            setExtractedValues((prev) => ({
              ...prev,
              [key]: text,
            }))
          }
          placeholder="Enter result"
          keyboardType="numeric"
        />
      </View>
    ))}
  </View>
)}




      {suggestions.length > 0 && (
        <View style={styles.suggestionBox}>
          <Text style={styles.extractedTitle}>🧪 Suggestions:</Text>
          {suggestions.map((sug, idx) => (
            <View key={idx} style={{ marginBottom: 6 }}>
              <Text style={{ fontWeight: '600' }}>{sug}</Text>
              <Text style={{ fontSize: 12, color: '#666' }}>
                {testDictionary[sug as keyof typeof testDictionary] || 'No info available'}
              </Text>
            </View>
          ))}
        </View>
      )}

      <Pressable style={styles.saveButton} onPress={handleUpdate}>
        <Text style={styles.saveText}>Save Changes</Text>
      </Pressable>

      <Pressable style={styles.backButton} onPress={() => router.back()}>
        <Text style={styles.backText}>Back</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    marginBottom: 20,
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    marginBottom: 20,
  },
  dateButton: {
    padding: 12,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    marginBottom: 20,
  },
  imageButton: {
    backgroundColor: '#eee',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 10,
  },
  imageButtonText: {
    fontWeight: '500',
    color: '#007AFF',
  },
  previewImage: {
    width: '100%',
    height: 200,
    borderRadius: 8,
    marginBottom: 20,
  },
  saveButton: {
    backgroundColor: '#1e90ff',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  backButton: {
    marginTop: 12,
    padding: 12,
    borderColor: '#999',
    borderWidth: 1,
    borderRadius: 8,
    alignItems: 'center',
  },
  backText: {
    color: '#333',
  },
  extractedBox: {
    backgroundColor: '#f1f8ff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
  extractedTitle: {
    fontWeight: 'bold',
    color: '#007AFF',
    marginBottom: 6,
  },
  extractedItem: {
    fontSize: 14,
    marginBottom: 4,
    color: '#444',
  },
  suggestionBox: {
    backgroundColor: '#fefce8',
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
});
