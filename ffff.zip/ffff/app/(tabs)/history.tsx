import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  Pressable,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { getAuth, signOut } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDocs,
  orderBy,
  query,
  where,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useRouter } from 'expo-router';

export default function History() {
  const [tests, setTests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const router = useRouter();
  const auth = getAuth();
  const user = auth.currentUser;

  const categories = ['All', 'Blood', 'Urine', 'X-Ray', 'MRI', 'Other'];

  useEffect(() => {
    if (!user) return;

    const fetchTests = async () => {
      try {
        const q = query(
          collection(db, 'medicalTests'),
          where('userId', '==', user.uid),
          orderBy('date', 'desc')
        );
        const snapshot = await getDocs(q);
        const items = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setTests(items);
      } catch (error) {
        console.error('Failed to fetch tests:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTests();
  }, [user]);

  const handleDelete = async (id: string) => {
    Alert.alert('Delete Test', 'Are you sure you want to delete this test?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteDoc(doc(db, 'medicalTests', id));
            setTests((prev) => prev.filter((test) => test.id !== id));
          } catch (err) {
            console.error('Failed to delete:', err);
          }
        },
      },
    ]);
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      router.replace('/login');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const filteredTests =
    selectedCategory === 'All'
      ? tests
      : tests.filter((test) => test.category === selectedCategory);

  if (loading) return <ActivityIndicator style={{ marginTop: 50 }} />;

  return (
    <View style={styles.container}>
      <Pressable style={styles.addButton} onPress={() => router.push('(tabs)/add-manual')}>
        <Text style={styles.addText}>+ Add Test</Text>
      </Pressable>

      <View style={styles.categoryContainer}>
        <FlatList
          data={categories}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={(item) => item}
          renderItem={({ item }) => (
            <Pressable
              style={[
                styles.categoryItem,
                selectedCategory === item && styles.selectedCategory,
              ]}
              onPress={() => setSelectedCategory(item)}
            >
              <Text style={styles.categoryText}>{item}</Text>
            </Pressable>
          )}
        />
      </View>

      {filteredTests.length === 0 ? (
        <Text style={styles.noTests}>No medical tests found.</Text>
      ) : (
        <FlatList
          data={filteredTests}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <Text style={styles.name}>{item.name || 'Unnamed Test'}</Text>
              <Text style={styles.details}>📅 {item.date}</Text>
              <Text style={styles.details}>📂 {item.category}</Text>

              {/* ✅ عرض القيم المستخرجة إن وجدت */}
              {/*
              {item.extractedValues && Object.keys(item.extractedValues).length > 0 && (
                <View style={{ marginTop: 10 }}>
                  <Text style={{ fontWeight: 'bold', marginBottom: 5 }}>Extracted Values:</Text>
                  {Object.entries(item.extractedValues).map(([key, value]) => (
                    <Text key={key} style={{ color: '#444' }}>
                      {key}: {String(value)}
                    </Text>
                  ))}
                </View>
                
              ) */}

              {item.imageUri && (
                <Image
                  source={{ uri: item.imageUri }}
                  style={styles.image}
                  onError={() =>
                    console.warn(`❌ Failed to load image: ${item.imageUri}`)
                  }
                />
              )}
              <View style={styles.buttonsRow}>
                <Pressable
                  style={[styles.actionButton, { backgroundColor: '#007AFF' }]}
                  onPress={() =>
                    router.push({ pathname: '/editTest', params: { id: item.id } })
                  }
                >
                  <Text style={styles.buttonText}>Edit</Text>
                </Pressable>
                <Pressable
                  style={[styles.actionButton, { backgroundColor: '#ff3b30' }]}
                  onPress={() => handleDelete(item.id)}
                >
                  <Text style={styles.buttonText}>Delete</Text>
                </Pressable>
              </View>
            </View>
          )}
        />
      )}

      <Pressable style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutText}>Logout</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
    backgroundColor: '#fff',
  },
  addButton: {
    backgroundColor: '#1e90ff',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 10,
  },
  addText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  categoryContainer: {
    height: 40,
    marginBottom: 10,
    justifyContent: 'center',
  },
  categoryItem: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#eee',
    borderRadius: 20,
    marginRight: 10,
  },
  selectedCategory: {
    backgroundColor: '#1e90ff',
  },
  categoryText: {
    color: '#333',
    fontSize: 16,
    fontWeight: '500',
  },
  noTests: {
    textAlign: 'center',
    marginTop: 50,
    fontSize: 16,
    color: '#666',
  },
  card: {
    backgroundColor: '#f9f9f9',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    elevation: 2,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  details: {
    marginTop: 4,
    color: '#555',
  },
  image: {
    width: '100%',
    height: 200,
    marginTop: 10,
    borderRadius: 8,
  },
  buttonsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  actionButton: {
    flex: 0.48,
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
  },
  logoutButton: {
    backgroundColor: '#555',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  logoutText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});
